#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"

RFC_RC SAP_API stfc_connection_impl(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc = RFC_OK;
	SAP_UC requtext[256], buf[256];

	rc = RfcGetString(funcHandle, cU("REQUTEXT"), requtext, 256, NULL, errorInfo);
	printfU(cU("Got request for STFC_CONNECTION.\nREQUTEXT = %s\n\n"), requtext);
	sprintfU(buf, cU("STFC_CONNECTION called with REQUTEXT = %s"), requtext);
	rc = RfcSetString(funcHandle, cU("ECHOTEXT"), buf, strlenU(buf), errorInfo);

	return rc;
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_CONNECTION_PARAMETER loginParams[1];
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_HANDLE connection;
	RFC_FUNCTION_DESC_HANDLE z_perform_callback, stfc_connection;
	RFC_FUNCTION_HANDLE functionContainer;
	SAP_UC data[256];

	loginParams[0].name = cU("dest");	loginParams[0].value = cU("SPJ");

	connection = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n"), errorInfo.message);
		printfU(cU("Please check that the sapnwrfc.ini file is in the current\nworking directory and the logon parameters are ok.\n"));
		return 1;
	}

	/* Note: In the following all error handling is omitted for simplicity. */
	z_perform_callback = RfcGetFunctionDesc(connection, cU("Z_PERFORM_CALLBACK"), &errorInfo);
	stfc_connection = RfcGetFunctionDesc(connection, cU("STFC_CONNECTION"), &errorInfo);

	// The stfc_connection_impl function will be called from R/3 during the RfcInvoke step below!
	rc = RfcInstallServerFunction(NULL, stfc_connection, stfc_connection_impl, &errorInfo);

	functionContainer = RfcCreateFunction(z_perform_callback, &errorInfo);

	rc = RfcSetString(functionContainer, cU("INPUT_DATA"), cU("Original Request"), 16, &errorInfo);
	rc = RfcInvoke(connection, functionContainer, &errorInfo);
	rc = RfcGetString(functionContainer, cU("OUTPUT_DATA"), data, 256, NULL, &errorInfo);

	RfcCloseConnection(connection, NULL);

	printfU(cU("Response from Z_PERFORM_CALLBACK: OUTPUT_DATA = %s\n"), data);
	return 0;
}