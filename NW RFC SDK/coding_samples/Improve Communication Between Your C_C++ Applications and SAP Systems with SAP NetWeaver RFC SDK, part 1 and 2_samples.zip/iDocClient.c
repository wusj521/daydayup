#include <stdlib.h>
#include <stdio.h>
#include "statusTracking.h"

SAP_UC buffer[512];
char bufferC[121];
RFC_FUNCTION_DESC_HANDLE iDocInboundDesc = NULL;
FILE* docnumFile = NULL;
unsigned docnum; // We certainly assume to be running single-threaded here...
SAP_UC DOCNUM[17];
RFC_CONNECTION_PARAMETER loginParams[1];


int initialScreen(void){
	int choice = 0;
	while(choice < 1 || choice > 3){
		printfU(cU("\n\nPlease select one of the following choices:\n"));
		printfU(cU("\t1: Send a new IDoc\n"));
		printfU(cU("\t2: Display currently pending IDocs\n"));
		printfU(cU("\t3: Exit\n\n\t> "));

		scanfU(cU("%d"), &choice); fflush(stdin);
		printfU(cU("\n"));
	}
	return choice;
}

int initIDoc(RFC_FUNCTION_HANDLE* iDoc, RFC_ERROR_INFO* error){
	RFC_TABLE_HANDLE table;
	RFC_RC rc;

	*iDoc = RfcCreateFunction(iDocInboundDesc, error);
	if (*iDoc == NULL) return 1;

	rc = RfcGetTable(*iDoc, cU("IDOC_CONTROL_REC_40"), &table, error);
	if (rc != RFC_OK) return 1;
	RfcAppendNewRow(table, error);
	if (error->code != RFC_OK) return 1;

	RfcSetString(table, cU("TABNAM"), cU("EDI_DC40"), 8, error);
	RfcSetString(table, cU("MANDT"), cU("000"), 3, error);
	RfcSetString(table, cU("DIRECT"), cU("2"), 1, error);
	RfcSetString(table, cU("IDOCTYP"), cU("TXTRAW01"), 8, error);
	RfcSetString(table, cU("MESTYP"), cU("TXTRAW"), 6, error);
	RfcSetString(table, cU("SNDPRT"), cU("LS"), 2, error);
	RfcSetString(table, cU("SNDPRN"), cU("SPJ_DEMO"), 8, error);
	RfcSetString(table, cU("RCVPRT"), cU("LS"), 2, error);
	RfcSetString(table, cU("RCVPRN"), cU("T90CLNT090"), 10, error);

	return 0;
}

int fillIDoc(RFC_FUNCTION_HANDLE iDoc, RFC_ERROR_INFO* error){
	RFC_TABLE_HANDLE table;
	RFC_RC rc;
	int lines = 0, size, i, min;
	SAP_UC segnum[16];

	rc = RfcGetTable(iDoc, cU("IDOC_CONTROL_REC_40"), &table, error);
	if (rc != RFC_OK) return 1;

	RfcMoveToFirstRow(table, NULL);
	RfcSetChars(table, cU("DOCNUM"), DOCNUM, 16, error);

	rc = RfcGetTable(iDoc, cU("IDOC_DATA_REC_40"), &table, error);
	if (rc != RFC_OK) return 1;

	while(lines < 1){
		printfU(cU("Please enter the number of segments (1-3600): "));
		scanf_s("%d", &lines);
		fflush(stdin);
	}

	RfcGetRowCount(table, &size, NULL);
	min = lines;
	if (min > size) min = size;

	// First reuse existing lines
	RfcMoveToFirstRow(table, NULL);
	for (i=1; i<=min; i++){
		if (rc != RFC_OK) return 1;
		RfcSetString(table, cU("SEGNAM"), cU("E1TXTRW"), 7, error);
		RfcSetString(table, cU("MANDT"), cU("000"), 3, error);
		RfcSetChars(table, cU("DOCNUM"), DOCNUM, 16, error);
		convertToNUMC(i, segnum);
		RfcSetChars(table, cU("SEGNUM"), segnum+10, 6, error);
		printfU(cU("Please enter the next value for E1TXTRW-TLINE (CHAR72): "));
		getsU(buffer);
		RfcSetString(table, cU("SDATA"), buffer, strlenU(buffer), error);
		rc = RfcMoveToNextRow(table, error);
	}

	// i is now min+1. So if we enter this loop, it means that min=size, so we need to append new rows
	for (; i<=lines; i++){
		RfcAppendNewRow(table, error);
		if (error->code != RFC_OK) return 1;
		RfcSetString(table, cU("SEGNAM"), cU("E1TXTRW"), 7, error);
		RfcSetString(table, cU("MANDT"), cU("000"), 3, error);
		RfcSetChars(table, cU("DOCNUM"), DOCNUM, 16, error);
		convertToNUMC(i, segnum);
		RfcSetChars(table, cU("SEGNUM"), segnum+10, 6, error);
		printfU(cU("Please enter the next value for E1TXTRW-TLINE (CHAR72): "));
		getsU(buffer);
		RfcSetString(table, cU("SDATA"), buffer, strlenU(buffer), error);
	}

	// If this loop is entered, it means that min=lines, so we need to delete superfluous lines from the table
	// The RfcMoveToNextRow() in the last loop-execution of the "i<=min" loop has already moved the cursor to
	// the correct line...
	for (; i<=size; i++) RfcDeleteCurrentRow(table, NULL);

	return 0;
}

int initDocnum(void){
	size_t result = 0;

	DOCNUM[16] = 0;
	docnumFile = fopen("docnumFile", "r+");
	if (docnumFile == NULL){ // Does not yet exist. Try to create a fresh one.
		docnum = 0;
		docnumFile = fopen("docnumFile", "w+");
		if (docnumFile == NULL){
			perror("Error opening DOCNUM file: ");
			return 1;
		}
		result = fwrite(&docnum, sizeof(unsigned), 1, docnumFile);
		if (result != 1){
			perror("Error writing DOCNUM file: ");
			fclose(docnumFile);
			return 1;
		}
		fflush(docnumFile);
	}
	else{
		result = fread(&docnum, sizeof(unsigned), 1, docnumFile);
		if (result != 1){
			perror("Error reading DOCNUM file: ");
			fclose(docnumFile);
			return 1;
		}
	}
	convertToNUMC(docnum, DOCNUM);
	return 0;
}

int incrementDocnum(void){
	size_t result;

	docnum++;
	convertToNUMC(docnum, DOCNUM);
	rewind(docnumFile);
	result = fwrite(&docnum, sizeof(unsigned), 1, docnumFile);
	if (result != 1){
		perror("Error writing DOCNUM file: ");
		fclose(docnumFile);
		return 1;
	}
	fflush(docnumFile);
	return 0;
}

void test(void){
	StoreRC rc;
	void* store;
	unsigned result, i, length=17;
	char doc[17];
	unsigned* indices;
	TIDStatus status;

	rc = openTIDStore("teststore", &store);
	if (rc != RC_OK) return;

	overView(store);
	for (i=0; i<15; i+=5){
	//	incrementDocnum();
	//	RfcSAPUCToUTF8(DOCNUM,  16, doc, &length,  &result, NULL);
		rc = deleteEntry(store, i);
		if (rc != RC_OK) return;
	}
	overView(store);

	rc = getInitialEntries(store, &result, &indices);
	if (rc != RC_OK) return;
	for (i=0; i< result; i++) printf("\t%d\n", indices[i]);

	rc = setTID(store, 4, "12345678901234567890abce");
	if (rc != RC_OK) return;
	rc = getEntry(store, "12345678901234567890abcd", NULL, &result);
	if (rc != AlreadyExisting) return;
	rc = setTIDStatus(store, result, Status_RolledBack, "Grober Fehler");
	printEntry(store, result);

	rc = getTIDStatus(store, result, &status);
	if (status != Status_RolledBack) return;

	rc = deleteEntry(store, 7);
	if (rc != RC_OK) return;

	incrementDocnum();
	RfcSAPUCToUTF8(DOCNUM,  16, doc, &length,  &result, NULL);
	rc = getEntry(store, "09876543210987654321ABCD", doc, &result);
	if (rc != RC_OK) return;

	closeTIDStore(store);
}

void fireIDoc(RFC_CONNECTION_HANDLE* connection, void* tidStore, unsigned index, RFC_TID tid, SAP_UC* dnum, RFC_FUNCTION_HANDLE iDoc, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc;
	StoreRC store_rc;
	unsigned length = 121, dontCare;
	RFC_TRANSACTION_HANDLE tHandle = RfcCreateTransaction(*connection, tid, NULL, errorInfo);

	if (tHandle == NULL){
		printfU(cU("Error creating a transaction handle: %s\n"), errorInfo->message);
		goto rollback;
	}

	rc = RfcInvokeInTransaction(tHandle, iDoc, errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error adding IDoc to transaction: %s\n"), errorInfo->message);
		goto rollback;
	}

	rc = RfcSubmitTransaction(tHandle, errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error sending IDoc: %s\n"), errorInfo->message);
		goto rollback;
	}

	// At this point we can guarantee that the IDoc reached the backend savely.
	printfU(cU("IDoc %s successfully sent using TID %s\n"), dnum, tid);
	deleteMessageBody(iDoc);
	store_rc = deleteEntry(tidStore, index);
	if (store_rc != RC_OK){
		RfcDestroyTransaction(tHandle, NULL);
		return;
	}

	// If we get here, the TID entry has been deleted, so there's no danger of ever
	// sending the same IDoc again. Now we can cleanup the TID in the backend:
	RfcConfirmTransaction(tHandle, NULL);

	RfcDestroyTransaction(tHandle, NULL);
	return;

	rollback:
		RfcDestroyTransaction(tHandle, NULL);
		if (RfcSAPUCToUTF8(errorInfo->message,  100, bufferC, &length, &dontCare, NULL) != RFC_OK)
			strcpy_s(bufferC, 81, "Error firing the IDoc");
		setTIDStatus(tidStore, index, Status_RolledBack, bufferC);

		/* IDOC_INBOUND_ASYNCHRONOUS doesn't throw any ABAP Exceptions.
		So normally, if an IDoc fails, we get a "hard error". This means
		the connection is closed afterwards. Try to reconnect in these cases. */
		if (rc == RFC_COMMUNICATION_FAILURE || rc == RFC_ABAP_MESSAGE || rc == RFC_ABAP_RUNTIME_FAILURE)
			*connection = RfcOpenConnection(loginParams, 1, errorInfo);
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	StoreRC store_rc;
	int error = 0;
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_HANDLE connection;
	RFC_FUNCTION_HANDLE iDocInbound = NULL;
	RFC_TABLE_HANDLE table;
	RFC_TID tid;
	void* tidStore;
	unsigned length, index, dontCare;
	SAP_UC docnumU[17];
	char docnumC[17];
	char tidC[25];
	RFC_ATTRIBUTES attributes;

	loginParams[0].name = cU("dest");	loginParams[0].value = cU("SPJ");

	store_rc = openTIDStore("idoc_client_store", &tidStore);
	if (store_rc != RC_OK) return 1;

	if (initDocnum()){
		closeTIDStore(tidStore);
		return 1;
	}

	connection = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n"), errorInfo.message);
		printfU(cU("Please check that the sapnwrfc.ini file is in the current\nworking directory and the logon parameters are ok.\n"));
		closeTIDStore(tidStore);
		fclose(docnumFile);
		return 1;
	}
	rc = RfcGetConnectionAttributes(connection, &attributes, NULL);
	if (rc == RFC_OK)
		printfU(cU("Successfully logged on to destination SPJ (System-ID %s)\n"), attributes.sysId);

	iDocInboundDesc = RfcGetFunctionDesc(connection, cU("IDOC_INBOUND_ASYNCHRONOUS"), &errorInfo);
	if (iDocInboundDesc == NULL){
		printfU(cU("Error getting metadata: %s\n"), errorInfo.message);
		error = 1;
		goto end;
	}

	if (initIDoc(&iDocInbound, &errorInfo)){
		printfU(cU("Error creating function container: %s\n"), errorInfo.message);
		error = 1;
		goto end;
	}

	while (1){
		switch (initialScreen()){
			case 1: // We want to create and send a new IDoc
				if (incrementDocnum()) break;
				length = 17;
				RfcSAPUCToUTF8(DOCNUM,  16, docnumC, &length, &dontCare, NULL);
				printf("Created next DOCNUM: %s.\n", docnumC);

				if (fillIDoc(iDocInbound, &errorInfo)) break;

				if (saveMessageBody(iDocInbound)) break;
				printf("Saved data for IDoc %s.\n", docnumC);

				store_rc = getEntry(tidStore, NULL, docnumC, &index);
				if (store_rc != RC_OK) break;

				rc = RfcGetTransactionID(connection, tid, &errorInfo);
				if (rc != RFC_OK){
					printfU(cU("Error getting a TID: %s\n"), errorInfo.message);
					length = 81;
					rc = RfcSAPUCToUTF8(errorInfo.message,  60, bufferC, &length, &dontCare, NULL);
					if (rc != RFC_OK) strcpy_s(bufferC, 81, "Error getting a TID");
					setTIDStatus(tidStore, index, Status_RolledBack, bufferC);
					// An error in RfcGetTransactionID() can only mean a problem with the connection.
					// Try a reconnect.
					connection = RfcOpenConnection(loginParams, 1, &errorInfo);
					if (connection == NULL){
						printfU(cU("Error during re-logon: %s\n"), errorInfo.message);
						error = 1;
						goto end;
					}
					break;
				}

				length = 25;
				RfcSAPUCToUTF8(tid,  24, tidC, &length, &dontCare, NULL);
				store_rc = setTID(tidStore, index, tidC);
				if (store_rc != RC_OK) break;
				printf("Set TID to %s.\n", tidC);

				fireIDoc(&connection, tidStore, index, tid, DOCNUM, iDocInbound, &errorInfo);
				// fireIDoc() does all the error & status handling and reconnects if necessary.
				// If the reconnect failed, it's a network problem and we should quit.
				if (connection == NULL){
					printfU(cU("Error during re-logon: %s\n"), errorInfo.message);
					error = 1;
					goto end;
				}
				break;

			case 2: // We want to view the currently pending IDocs and possibly resend one of them.
				store_rc = overView(tidStore);
				if (store_rc == RC_OK){
					printf("\nPlease enter the index of an IDoc to resend, or \"x\" to continue: ");
					gets_s(bufferC, 81);
					if (*bufferC == 'x') break;
					index = atoi(bufferC);

					store_rc = getDetails(tidStore, index, tidC, docnumC);
					switch (store_rc){
						case InvalidParameter:
							printf("This is not a valid index\n");
							continue;
						case IOError:
							printf("Quitting\n");
							goto end;
					}

					if (*tidC == 0){ // Still need a TID for this entry...
						rc = RfcGetTransactionID(connection, tid, &errorInfo);
						if (rc != RFC_OK){
							printfU(cU("Error getting a TID: %s\n"), errorInfo.message);
							length = 81;
							rc = RfcSAPUCToUTF8(errorInfo.message,  60, bufferC, &length, &dontCare, NULL);
							if (rc != RFC_OK) strcpy_s(bufferC, 81, "Error getting a TID");
							setTIDStatus(tidStore, index, Status_RolledBack, bufferC);
							// An error in RfcGetTransactionID() can only mean a problem with the connection.
							// Try a reconnect.
							connection = RfcOpenConnection(loginParams, 1, &errorInfo);
							if (connection == NULL){
								printfU(cU("Error during re-logon: %s\n"), errorInfo.message);
								error = 1;
								goto end;
							}
							break;
						}
						length = 25;
						RfcSAPUCToUTF8(tid,  24, tidC, &length, &dontCare, NULL);
						store_rc = setTID(tidStore, index, tidC);
						if (store_rc != RC_OK) break;
						printf("Set TID to %s.\n", tidC);
					}
					else{
						length = 25;
						RfcUTF8ToSAPUC(tidC, 24, tid, &length, &dontCare, NULL);
					}

					length = 17;
					RfcUTF8ToSAPUC(docnumC, 16, docnumU, &length, &dontCare, NULL);
					RfcGetTable(iDocInbound, cU("IDOC_CONTROL_REC_40"),&table, NULL);
					RfcSetChars(table, cU("DOCNUM"), docnumU, 16, NULL);
					store_rc = readMessageBody(iDocInbound);
					if (store_rc != RC_OK) break;

					fireIDoc(&connection, tidStore, index, tid, docnumU, iDocInbound, &errorInfo);
					if (connection == NULL){
						printfU(cU("Error during re-logon: %s\n"), errorInfo.message);
						error = 1;
						goto end;
					}
				}
				break;

			case 3: // We are done for now.
				goto end;
		}
	}

	end:
	if (connection != NULL) RfcCloseConnection(connection, NULL);
	closeTIDStore(tidStore);
	fclose(docnumFile);
	return error;
}