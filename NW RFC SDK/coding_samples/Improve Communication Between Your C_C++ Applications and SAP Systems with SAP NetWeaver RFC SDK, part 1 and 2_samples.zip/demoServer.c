#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"

#define _CRT_SECURE_NO_WARNINGS

// Defined in helperFunctions.c
extern void readValue(SAP_UC* buffer, int max);
extern int userSaysYes(void);
extern void printParameter(RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container);
extern void fillParameter(int* index, RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container);

static int listening = 1;

void printImports(RFC_FUNCTION_DESC_HANDLE description, RFC_FUNCTION_HANDLE container){
	unsigned i, parameterCount;
	RFC_PARAMETER_DESC paramDesc;

	RfcGetParameterCount(description, &parameterCount, NULL);
	
	printfU(cU("Here are the values of the IMPORTING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_IMPORT){
			printParameter(paramDesc, container);
		}
	}

	printfU(cU("\nHere are the values of the CHANGING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_CHANGING){
			printParameter(paramDesc, container);
		}
	}

	printfU(cU("\nHere are the values of the TABLES parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_TABLES){
			printParameter(paramDesc, container);
		}
	}
}

void fillExports(RFC_FUNCTION_DESC_HANDLE description, RFC_FUNCTION_HANDLE container){
	unsigned i, parameterCount;
	RFC_PARAMETER_DESC paramDesc;

	RfcGetParameterCount(description, &parameterCount, NULL);
	
	printfU(cU("Please enter the EXPORTING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_EXPORT){
			fillParameter(&i, paramDesc, container);
		}
	}

	printfU(cU("\nPlease enter the CHANGING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_CHANGING){
			fillParameter(&i, paramDesc, container);
		}
	}

	printfU(cU("\nPlease enter the TABLES parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_TABLES){
			fillParameter(&i, paramDesc, container);
		}
	}
}

RFC_RC checkAuthorization(RFC_ABAP_NAME funcName, RFC_ATTRIBUTES attributes){
	printfU(cU("AuthorizationCheck: User %s from system %s, client %s, host %s is trying to invoke %s.\n"),
				attributes.user, attributes.sysId, attributes.client, attributes.partnerHost, funcName);
	printfU(cU("Allow access? [y/n] "));
	if (userSaysYes()) return RFC_OK;
	return RFC_EXTERNAL_FAILURE;
}

void fillSyMsg(RFC_ERROR_INFO* perrorInfo){
	SAP_UC value[53];

	printfU(cU("Please enter a value for SY-MSGTY [E/A/X]: "));
	readValue(value, 53);
	value[1] = 0;
	strncpyU(perrorInfo->abapMsgType, value, 2);

	printfU(cU("Please enter a value for SY-MSGID (CHAR20): "));
	readValue(value, 53);
	value[20] = 0;
	strncpyU(perrorInfo->abapMsgClass, value, strlenU(value));

	printfU(cU("Please enter a value for SY-MSGNO [000-999]: "));
	readValue(value, 53);
	value[3] = 0;
	strncpyU(perrorInfo->abapMsgNumber, value, strlenU(value));

	printfU(cU("Please enter a value for SY-MSGV1 (CHAR50): "));
	readValue(value, 53);
	value[50] = 0;
	strncpyU(perrorInfo->abapMsgV1, value, strlenU(value));

	printfU(cU("Please enter a value for SY-MSGV2 (CHAR50): "));
	readValue(value, 53);
	value[50] = 0;
	strncpyU(perrorInfo->abapMsgV2, value, strlenU(value));

	printfU(cU("Please enter a value for SY-MSGV3 (CHAR50): "));
	readValue(value, 53);
	value[50] = 0;
	strncpyU(perrorInfo->abapMsgV3, value, strlenU(value));

	printfU(cU("Please enter a value for SY-MSGV4 (CHAR50): "));
	readValue(value, 53);
	value[50] = 0;
	strncpyU(perrorInfo->abapMsgV4, value, strlenU(value));
}

void errorThrowing(RFC_FUNCTION_DESC_HANDLE metadata, RFC_ERROR_INFO* errorInfo){
	unsigned i, index = 2, paramCount = 0, choice = 0;
	RFC_EXCEPTION_DESC excepDesc;
	SAP_UC value[203];

	errorInfo->code = RFC_OK;

	printfU(cU("For this function we can throw the following errors:\n"));
	printfU(cU("1. SYSTEM_FAILURE\n"));
	printfU(cU("2. ABAP Message\n"));

	RfcGetExceptionCount(metadata, &paramCount, NULL);
	for (i=0; i<paramCount; i++){
		RfcGetExceptionDescByIndex(metadata, i, &excepDesc, NULL);
		printfU(cU("%d. %s: %s\n"), ++index, excepDesc.key, excepDesc.message);
	}

	printfU(cU("Please enter a value between 1 and %d or \"n\" for not throwing an exception: "), index);
	readValue(value, 203);

	if (strncmpU(value, cU("n"), 1) == 0) return;

	choice = atoiU(value);
	if (choice < 1 || choice > index) return;

	switch (choice){
		case 1:
			printfU(cU("Please enter a value for the message (200): "));
			readValue(value, 203);  // In the worst case we need one extra for each of \r\n\0
			i = strlenU(value);
			strncpyU(errorInfo->message, value, i<200?i:200);
			errorInfo->code = RFC_EXTERNAL_FAILURE;
			break;
		case 2:
			fillSyMsg(errorInfo);
			errorInfo->code = RFC_ABAP_MESSAGE;
			break;
		default:
			errorInfo->code = RFC_ABAP_EXCEPTION;
			index = choice - 3;
			RfcGetExceptionDescByIndex(metadata, index, &excepDesc, NULL);
			strncpyU(errorInfo->key, excepDesc.key, strlenU(excepDesc.key));
			printfU(cU("Do you want to send some SY-MSG variables together with the ABAP Exception? [y/n] "));
			if (userSaysYes()) fillSyMsg(errorInfo);
	}
}

RFC_RC SAP_API repositoryLookup(SAP_UC const *functionName, RFC_ATTRIBUTES rfcAttributes, RFC_FUNCTION_DESC_HANDLE *funcDescHandle){
	RFC_CONNECTION_PARAMETER loginParams[1];
	RFC_CONNECTION_HANDLE repoCon;
	RFC_ERROR_INFO errorInfo;

	printfU(cU("Repository: %s not yet cached. Checking backend's DDIC.\n"), functionName);
	loginParams->name = cU("dest");
	loginParams->value = rfcAttributes.sysId;
	repoCon = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (repoCon == NULL){
		printfU(cU("Repository: unable to connect to %s: %s: %s\n"), rfcAttributes.sysId,
				RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return RFC_NOT_FOUND;
	}
	*funcDescHandle = RfcGetFunctionDesc(repoCon, functionName, &errorInfo);
	RfcCloseConnection(repoCon, NULL);
	if (*funcDescHandle == NULL){
		printfU(cU("Repository: unable to find metadata for %s: %s: %s\n\n"), functionName,
				RfcGetRcAsString(errorInfo.code), errorInfo.key);
		return RFC_NOT_FOUND;
	}

	printfU(cU("Repository: successfully retrieved metadata information for %s\n\n"), functionName);
	return RFC_OK;
}

RFC_RC SAP_API genericRequestHandler(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc;
	RFC_ATTRIBUTES attributes;
	RFC_FUNCTION_DESC_HANDLE metadata;
	RFC_ABAP_NAME funcName;

	printfU(cU("\n---------------------------------------\n"));
	RfcGetConnectionAttributes(rfcHandle, &attributes, NULL);
	metadata = RfcDescribeFunction(funcHandle, NULL);
	RfcGetFunctionName(metadata, funcName, NULL);

	rc = checkAuthorization(funcName, attributes);
	if (rc != RFC_OK){
		errorInfo->code = RFC_EXTERNAL_FAILURE;
		strncpyU(errorInfo->message, cU("Access denied, my friend!"), 25);
		rc = RFC_EXTERNAL_FAILURE;
		goto end;
	}

	printfU(cU("\n"));
	printImports(metadata, funcHandle);

	printfU(cU("\n"));
	errorThrowing(metadata, errorInfo);
	if (errorInfo->code != RFC_OK){
		rc = errorInfo->code;
		goto end;
	}

	printfU(cU("\n"));
	fillExports(metadata, funcHandle);

	end: printfU(cU("\nStop listening after this request? [y/n] "));
	if (userSaysYes()) listening = 0;
	return rc;
}

void listen(RFC_CONNECTION_HANDLE* pserverHandle, RFC_CONNECTION_PARAMETER* params){
	RFC_RC rc;
	RFC_ERROR_INFO errorInfo;
	int refresh = 0;

	rc = RfcListenAndDispatch(*pserverHandle, 2, &errorInfo);
	switch (rc){
		case RFC_OK:
		case RFC_RETRY:
			break;
		case RFC_ABAP_EXCEPTION:
			printfU(cU("ABAP_EXCEPTION in implementing function: %s\n"), errorInfo.key);
			break;
		case RFC_NOT_FOUND:
			printfU(cU("Unknown function module: %s\n"), errorInfo.message);
			refresh = 1;
			break;
		case RFC_EXTERNAL_FAILURE:
			printfU(cU("SYSTEM_FAILURE has been sent to backend: %s\n"), errorInfo.message);
			refresh = 1;
			break;
		case RFC_ABAP_MESSAGE:
			printfU(cU("ABAP Message has been sent to backend: %s %s %s\n"), errorInfo.abapMsgType,
						errorInfo.abapMsgClass, errorInfo.abapMsgNumber);
			printfU(cU("Variables: V1=%s V2=%s V3=%s V4=%s\n"), errorInfo.abapMsgV1,
						errorInfo.abapMsgV2, errorInfo.abapMsgV3, errorInfo.abapMsgV4);
			refresh = 1;
			break;
		case RFC_COMMUNICATION_FAILURE:
		case RFC_CLOSED:
			printfU(cU("Connection broke down during transmission of return values: %s\n"), errorInfo.message);
			refresh = 1;
			break;
	}

	if (refresh){
		printfU(cU("Trying to reconnect...\n"));
		*pserverHandle = RfcRegisterServer(params, 1, &errorInfo);
		if (*pserverHandle == NULL){
			printfU(cU("Unable to reconnect to %s: %s: %s\n"), params->value,
					RfcGetRcAsString(errorInfo.code), errorInfo.message);
			printfU(cU("Stopping to listen at %s"), params->value);
		}
	}

	if (rc != RFC_RETRY && *pserverHandle != NULL && listening) printfU(cU("\nWaiting for request...\n"));
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_PARAMETER gatewayParams[1];
	RFC_CONNECTION_HANDLE serverHandle1, serverHandle2;
	SAP_UC* system1 = cU("SPJ_REG");
	SAP_UC* system2 = cU("MBS_REG");

	rc = RfcInstallGenericServerFunction(genericRequestHandler, repositoryLookup, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Unable to install RequestHandler: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	gatewayParams[0].name = cU("dest");
	gatewayParams[0].value = system1;
	serverHandle1 = RfcRegisterServer(gatewayParams, 1, &errorInfo);
	if (serverHandle1 == NULL) printfU(cU("Unable to register at %s: %s: %s\n"), system1,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
	else printfU(cU("Successfully registered at %s\n"), system1);

	gatewayParams[0].value = system2;
	serverHandle2 = RfcRegisterServer(gatewayParams, 1, &errorInfo);
	if (serverHandle2 == NULL){
		printfU(cU("Unable to register at %s: %s: %s\n"), system2, RfcGetRcAsString(errorInfo.code), errorInfo.message);
		if (serverHandle1 == NULL) return 1;
	}
	else printfU(cU("Successfully registered at %s\n"), system2);

	printfU(cU("\nWaiting for request...\n"));
	while(serverHandle1 != NULL || serverHandle2 != NULL){
		gatewayParams->value = system1;
		if (serverHandle1 != NULL) listen(&serverHandle1, gatewayParams);

		gatewayParams->value = system2;
		if (serverHandle2 != NULL) listen(&serverHandle2, gatewayParams);

		if (!listening) break;
	}

	if (serverHandle1 != NULL) RfcCloseConnection(serverHandle1, NULL);
	if (serverHandle2 != NULL) RfcCloseConnection(serverHandle2, NULL);

	return 0;
}