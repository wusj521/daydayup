#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"

#define BUF_SIZE 1024
static SAP_UC buffer[BUF_SIZE]; // This is not thread-safe, what I'm doing here...

void fillTable(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_TABLE_HANDLE container);
void printTable(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_TABLE_HANDLE container);

void readValue(SAP_UC* buf, int max){
	size_t length;
	fgetsU(buf, max, stdin); // Unfortunately gets_sU doesn't exist...
	length = strlenU(buf);
	if (buf[length-2] == cU('\r') || buf[length-2] == cU('\n')) buf[length-2] = 0;
	else if (buf[length-1] == cU('\n') || buf[length-1] == cU('\r')) buf[length-1] = 0;
}

int userSaysYes(void){
	SAP_UC buf[3];

	readValue(buf, 3);
	if (strncmpU(buf, cU("y"), 3) == 0) return 1;
	return 0;
}

void fillStructure(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_STRUCTURE_HANDLE container){
	unsigned i, j, fieldCount;
	RFC_RC rc;
	RFC_ERROR_INFO errorInfo;
	RFC_FIELD_DESC fieldDesc;
	RFC_STRUCTURE_HANDLE structure;
	RFC_TABLE_HANDLE table;

	RfcGetFieldCount(typeDesc, &fieldCount, NULL);

	for (i=0; i<fieldCount; i++){
		RfcGetFieldDescByIndex(typeDesc, i, &fieldDesc, NULL);
		for (j=0; j<indent; j++) printfU(cU("\t"));
		switch (fieldDesc.type){
			case RFCTYPE_STRUCTURE:
				printfU(cU("%s is a structure. Do you want to fill it? [y/n] "), fieldDesc.name);
				if (userSaysYes()){
					rc = RfcGetStructure(container, fieldDesc.name, &structure, &errorInfo);
					if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
						printfU(cU("Could not create container for %s: %s %s.\n"), fieldDesc.name,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
						printfU(cU("We'll need to do without it...\n"));
						continue;
					}
					fillStructure(indent+1, fieldDesc.typeDescHandle, structure);
				}
				break;
			case RFCTYPE_TABLE:
				printfU(cU("%s is a table. Do you want to fill it? [y/n] "), fieldDesc.name);
				if (userSaysYes()){
					rc = RfcGetTable(container, fieldDesc.name, &table, &errorInfo);
					if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
						printfU(cU("Could not create container for %s: %s %s.\n"), fieldDesc.name,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
						printfU(cU("We'll need to do without it...\n"));
						continue;
					}
					fillTable(indent+1, fieldDesc.typeDescHandle, table);
				}
				break;
			default:
				printfU(cU("%s, %s, Length %d: "), fieldDesc.name, RfcGetTypeAsString(fieldDesc.type), fieldDesc.nucLength);
				readValue(buffer, BUF_SIZE);
				rc = RfcSetString(container, fieldDesc.name, buffer, strlenU(buffer), &errorInfo);
				if (rc != RFC_OK){ //Probably the user entered some nonsense. Give him a second chance...
					printfU(cU("Could not set the value: %s %s.\n"),
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					printfU(cU("Try again? [y/n] "));
					if (userSaysYes()) i--;
				}
		}
	}
}

void printStructure(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_STRUCTURE_HANDLE container){
	unsigned i, j, fieldCount, resultLen;
	RFC_RC rc;
	RFC_ERROR_INFO errorInfo;
	RFC_FIELD_DESC fieldDesc;
	RFC_STRUCTURE_HANDLE structure;
	RFC_TABLE_HANDLE table;

	RfcGetFieldCount(typeDesc, &fieldCount, NULL);

	for (i=0; i<fieldCount; i++){
		RfcGetFieldDescByIndex(typeDesc, i, &fieldDesc, NULL);
		for (j=0; j<indent; j++) printfU(cU("\t"));
		switch (fieldDesc.type){
			case RFCTYPE_STRUCTURE:
				printfU(cU("%s is a structure. Do you want to see its values? [y/n] "), fieldDesc.name);
				if (userSaysYes()){
					rc = RfcGetStructure(container, fieldDesc.name, &structure, &errorInfo);
					if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
						printfU(cU("Could not obtain container for %s: %s %s.\n"), fieldDesc.name,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
						printfU(cU("We'll need to do without it...\n"));
						continue;
					}
					printStructure(indent+1, fieldDesc.typeDescHandle, structure);
				}
				break;
			case RFCTYPE_TABLE:
				rc = RfcGetTable(container, fieldDesc.name, &table, &errorInfo);
				if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
					printfU(cU("Could not obtain container for %s: %s %s.\n"), fieldDesc.name,
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					printfU(cU("We'll need to do without it...\n"));
					continue;
				}
				RfcGetRowCount(table, &resultLen, NULL);
				printfU(cU("%s is a table with %d lines. Do you want to see its values? [y/n] "), fieldDesc.name, resultLen);
				if (userSaysYes()){
					printTable(indent+1, fieldDesc.typeDescHandle, table);
				}
				break;
			default:
				printfU(cU("%s, %s, Length %d: "), fieldDesc.name, RfcGetTypeAsString(fieldDesc.type), fieldDesc.nucLength);
				rc = RfcGetString(container, fieldDesc.name, buffer, BUF_SIZE, &resultLen, &errorInfo);
				if (rc != RFC_OK){ //Probably the buffer is too short?!
					printfU(cU("Could not read the value: %s %s.\n"),
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					continue;
				}
				printfU(cU("%s\n"), buffer);
		}
	}
}

void fillTable(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_TABLE_HANDLE container){
	unsigned lines, i, j;
	RFC_STRUCTURE_HANDLE lineHandle;
	RFC_ERROR_INFO errorInfo;

	for (j=1; j<indent; j++) printfU(cU("\t"));
	printfU(cU("Please enter the number of lines: "));
	readValue(buffer, BUF_SIZE);
	lines = atoiU(buffer);

	for(i=0; i<lines; i++){
		lineHandle = RfcAppendNewRow(container, &errorInfo);
		if (lineHandle == NULL){ // Probably out of memory?!
			printfU(cU("Unable to create a new line: %s %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
			printfU(cU("Skipping the rest.\n"));
			break;
		}
		for (j=1; j<indent; j++) printfU(cU("\t"));
		printfU(cU("Please enter the values for line %d:\n"), i);
		fillStructure(indent, typeDesc, lineHandle);
	}
}

void printTable(unsigned indent, RFC_TYPE_DESC_HANDLE typeDesc, RFC_TABLE_HANDLE container){
	unsigned lines, i, j;
	RFC_ERROR_INFO errorInfo;

	RfcGetRowCount(container, &lines, &errorInfo);
	if (lines > 20){
		for (j=1; j<indent; j++) printfU(cU("\t"));
		printfU(cU("That's too many. Only printing the first 20...\n"));
		lines = 20;
	}

	for(i=0; i<lines; i++){
		RfcMoveTo(container, i, &errorInfo);
		for (j=1; j<indent; j++) printfU(cU("\t"));
		printfU(cU("Contents of line %d:\n"), i);
		printStructure(indent, typeDesc, container);
	}
}

/* I want to process the parameters sorted by IMPORTING, EXPORTING, CHANGING and TABLES,
   therefore this workaround is necessary.
*/
void fillParameter(int* index, RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container){
	RFC_RC rc;
	RFC_ERROR_INFO errorInfo;
	RFC_STRUCTURE_HANDLE structure;
	RFC_TABLE_HANDLE table;

	printfU(cU("%s "), desc.name);
	switch (desc.type){
		case RFCTYPE_STRUCTURE:
			printfU(cU("is a structure. Do you want to fill it? [y/n] "));
			if (userSaysYes()){
				rc = RfcGetStructure(container, desc.name, &structure, &errorInfo);
				if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
					printfU(cU("Could not create container for %s: %s %s.\n"), desc.name,
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					printfU(cU("We'll need to do without it...\n"));
					return;
				}
				fillStructure(1, desc.typeDescHandle, structure);
			}
			break;
		case RFCTYPE_TABLE:
			printfU(cU("is a table. Do you want to fill it? [y/n] "));
			if (userSaysYes()){
				rc = RfcGetTable(container, desc.name, &table, &errorInfo);
				if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
					printfU(cU("Could not create container for %s: %s %s.\n"), desc.name,
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					printfU(cU("We'll need to do without it...\n"));
					return;
				}
				fillTable(1, desc.typeDescHandle, table);
			}
			break;
		default:
			printfU(cU("%s, Length %d: "), RfcGetTypeAsString(desc.type), desc.nucLength);
			readValue(buffer, BUF_SIZE);
			rc = RfcSetString(container, desc.name, buffer, strlenU(buffer), &errorInfo);
			if (rc != RFC_OK){ //Probably the user entered some nonsense. Give him a second chance...
				printfU(cU("Could not set the value: %s %s.\n"),
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				printfU(cU("Try again? [y/n] "));
				if (userSaysYes()) (*index)--;
			}
	}
}

void printParameter(RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container){
	RFC_RC rc;
	RFC_ERROR_INFO errorInfo;
	RFC_STRUCTURE_HANDLE structure;
	RFC_TABLE_HANDLE table;
	unsigned resultLen, lines;

	switch (desc.type){
		case RFCTYPE_STRUCTURE:
			printfU(cU("%s is a structure. Do you want to see its values? [y/n] "), desc.name);
			if (userSaysYes()){
				rc = RfcGetStructure(container, desc.name, &structure, &errorInfo);
				if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
					printfU(cU("Could not obtain container for %s: %s %s.\n"), desc.name,
							RfcGetRcAsString(errorInfo.code), errorInfo.message);
					printfU(cU("We'll need to do without it...\n"));
					return;
				}
				printStructure(1, desc.typeDescHandle, structure);
			}
			break;
		case RFCTYPE_TABLE:
			rc = RfcGetTable(container, desc.name, &table, &errorInfo);
			if (rc != RFC_OK){ //Probably out of memory?! Bad luck...
				printfU(cU("Could not obtain container for table %s: %s %s.\n"), desc.name,
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				printfU(cU("We'll need to do without it...\n"));
				return;
			}
			RfcGetRowCount(table, &lines, NULL);
			printfU(cU("%s is a table with %d lines. Do you want to see its values? [y/n] "), desc.name, lines);
			if (userSaysYes()) printTable(1, desc.typeDescHandle, table);
			break;
		default:
			printfU(cU("%s, %s, Length %d: "), desc.name, RfcGetTypeAsString(desc.type), desc.nucLength);
			rc = RfcGetString(container, desc.name, buffer, BUF_SIZE, &resultLen, &errorInfo);
			if (rc != RFC_OK){ //Probably the buffer is too short?!
				printfU(cU("Could not read the value: %s %s.\n"),
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				return;
			}
			printfU(cU("%s\n"), buffer);
	}
}