#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"

// Defined in helperFunctions.c
extern void printImports(RFC_FUNCTION_DESC_HANDLE description, RFC_FUNCTION_HANDLE container);
extern void readValue(SAP_UC* buffer, int max);
extern int userSaysYes(void);

static int listening = 1;

RFC_FUNCTION_DESC_HANDLE constructFunctionDescription(RFC_ERROR_INFO* info){
	RFC_RC rc = RFC_OK;
	RFC_FUNCTION_DESC_HANDLE iDontExist;
	RFC_TYPE_DESC_HANDLE animals;
	RFC_FIELD_DESC fieldDescr;
	RFC_PARAMETER_DESC paramDescr;
	RFC_EXCEPTION_DESC excDescr;

	animals = RfcCreateTypeDesc(cU("ANIMALS"), info);
	if (animals == NULL) return NULL;

	strncpyU(fieldDescr.name, cU("LION"), 5);
	fieldDescr.type = RFCTYPE_CHAR;
	fieldDescr.nucLength = 5;
	fieldDescr.nucOffset = 0;
	fieldDescr.ucLength = 10;
	fieldDescr.ucOffset = 0;
	fieldDescr.decimals = 0;
	fieldDescr.typeDescHandle = NULL;
	fieldDescr.extendedDescription = NULL;
	rc = RfcAddTypeField(animals, &fieldDescr, info);
	if (rc != RFC_OK){
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(fieldDescr.name, cU("ELEPHANT"), 9);
	fieldDescr.type = RFCTYPE_FLOAT;
	fieldDescr.nucLength = 8;
	fieldDescr.nucOffset = 8;
	fieldDescr.ucLength = 8;
	fieldDescr.ucOffset = 16;
	fieldDescr.decimals = 16;
	rc = RfcAddTypeField(animals, &fieldDescr, info);
	if (rc != RFC_OK){
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(fieldDescr.name, cU("ZEBRA"), 6);
	fieldDescr.type = RFCTYPE_INT;
	fieldDescr.nucLength = 4;
	fieldDescr.nucOffset = 16;
	fieldDescr.ucLength = 4;
	fieldDescr.ucOffset = 24;
	fieldDescr.decimals = 0;
	rc = RfcAddTypeField(animals, &fieldDescr, info);
	if (rc != RFC_OK){
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	rc = RfcSetTypeLength(animals, 20, 28, info);
	if (rc != RFC_OK){
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	iDontExist = RfcCreateFunctionDesc(cU("I_DONT_EXIST"), info);
	if (iDontExist == NULL){
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("DOG"), 4);
	paramDescr.type = RFCTYPE_INT;
	paramDescr.direction = RFC_IMPORT;
	paramDescr.nucLength = 4;
	paramDescr.ucLength = 4;
	paramDescr.decimals = 0;
	paramDescr.defaultValue[0] = 0;
	paramDescr.typeDescHandle = NULL;
	paramDescr.extendedDescription = NULL;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("CAT"), 4);
	paramDescr.type = RFCTYPE_CHAR;
	paramDescr.direction = RFC_IMPORT;
	paramDescr.nucLength = 5;
	paramDescr.ucLength = 10;
	paramDescr.decimals = 0;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("ZOO"), 4);
	paramDescr.type = RFCTYPE_STRUCTURE;
	paramDescr.direction = RFC_IMPORT;
	paramDescr.nucLength = 20;
	paramDescr.ucLength = 28;
	paramDescr.decimals = 0;
	paramDescr.typeDescHandle = animals;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("BIRD"), 5);
	paramDescr.type = RFCTYPE_FLOAT;
	paramDescr.direction = RFC_IMPORT;
	paramDescr.nucLength = 8;
	paramDescr.ucLength = 8;
	paramDescr.decimals = 16;
	paramDescr.typeDescHandle = NULL;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("COW"), 4);
	paramDescr.type = RFCTYPE_CHAR;
	paramDescr.direction = RFC_EXPORT;
	paramDescr.nucLength = 3;
	paramDescr.ucLength = 6;
	paramDescr.decimals = 0;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("STABLE"), 7);
	paramDescr.type = RFCTYPE_STRUCTURE;
	paramDescr.direction = RFC_EXPORT;
	paramDescr.nucLength = 20;
	paramDescr.ucLength = 28;
	paramDescr.decimals = 0;
	paramDescr.typeDescHandle = animals;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(paramDescr.name, cU("HORSE"), 6);
	paramDescr.type = RFCTYPE_INT;
	paramDescr.direction = RFC_EXPORT;
	paramDescr.nucLength = 4;
	paramDescr.ucLength = 4;
	paramDescr.decimals = 0;
	paramDescr.typeDescHandle = NULL;
	rc = RfcAddParameter(iDontExist, &paramDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	strncpyU(excDescr.key, cU("NO_MORE_FOOD"), 13);
	rc = RfcAddException(iDontExist, &excDescr, info);
	if (rc != RFC_OK){
		RfcDestroyFunctionDesc(iDontExist, NULL);
		RfcDestroyTypeDesc(animals, NULL);
		return NULL;
	}

	return iDontExist;
}

RFC_RC SAP_API animalHandler(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc = RFC_OK;
	RFC_ATTRIBUTES attributes;
	RFC_STRUCTURE_HANDLE stable;
	SAP_UC buf[64];
	static int count = 0;

	RfcGetConnectionAttributes(rfcHandle, &attributes, NULL);
	printfU(cU("\nAnimalHandler: received request from %s\n"), attributes.sysId);

	*buf = 0;
	rc = RfcGetString(funcHandle, cU("DOG"), buf, 64, NULL, NULL);
	if (rc == RFC_OK) printfU(cU("DOG = %s\n"), buf);
	rc = RfcGetString(funcHandle, cU("CAT"), buf, 64, NULL, NULL);
	if (rc == RFC_OK) printfU(cU("CAT = %s\n"), buf);
	rc = RfcGetStructure(funcHandle, cU("ZOO"), &stable, NULL);
	if (rc == RFC_OK){
		printfU(cU("ZOO\n"));
		rc = RfcGetString(stable, cU("LION"), buf, 64, NULL, NULL);
		if (rc == RFC_OK) printfU(cU("\t-LION = %s\n"), buf);
		rc = RfcGetString(stable, cU("ELEPHANT"), buf, 64, NULL, NULL);
		if (rc == RFC_OK) printfU(cU("\t-ELEPHANT = %s\n"), buf);
		rc = RfcGetString(stable, cU("ZEBRA"), buf, 64, NULL, NULL);
		if (rc == RFC_OK) printfU(cU("\t-ZEBRA = %s\n"), buf);
	}
	rc = RfcGetString(funcHandle, cU("BIRD"), buf, 64, NULL, NULL);
	if (rc == RFC_OK) printfU(cU("BIRD = %s\n"), buf);

	if (++count == 3){
		count = 0;
		errorInfo->code = RFC_ABAP_EXCEPTION;
		errorInfo->group = ABAP_APPLICATION_FAILURE;
		strncpyU(errorInfo->key, cU("NO_MORE_FOOD"), 12);
		rc = RFC_ABAP_EXCEPTION;
	}
	else{
		RfcSetString(funcHandle, cU("COW"), cU("Muh"), 3, NULL);
		rc = RfcGetStructure(funcHandle, cU("STABLE"), &stable, errorInfo);
		if (rc != RFC_OK){ // errorInfo already set, just return SYSTEM_FAILURE.
			rc = RFC_EXTERNAL_FAILURE;
			errorInfo->code = rc;
		}
		else{
			RfcSetString(stable, cU("LION"), cU("Snore"), 5, NULL);
			RfcSetFloat(stable, cU("ELEPHANT"), 5.67E3L, NULL);
			RfcSetInt(stable, cU("ZEBRA"), 65537, NULL);
		}
		RfcSetInt(funcHandle, cU("HORSE"), -257, NULL);
	}

	printfU(cU("Stop listening after this call? [y/n] "));
	if (userSaysYes()) listening = 0;

	return rc;
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_PARAMETER gatewayParams[1];
	RFC_CONNECTION_HANDLE serverHandle;
	RFC_FUNCTION_DESC_HANDLE desc;
	SAP_UC* system = cU("SPJ_REG");

	desc = constructFunctionDescription(&errorInfo);
	if (desc == NULL){
		printfU(cU("Unable to create a function description: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	rc = RfcInstallServerFunction(NULL, desc, animalHandler, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Unable to install RequestHandler: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	gatewayParams->name = cU("dest");
	gatewayParams->value = system;
	serverHandle = RfcRegisterServer(gatewayParams, 1, &errorInfo);
	if (serverHandle == NULL) printfU(cU("Unable to register at %s: %s: %s\n"), system,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
	else printfU(cU("Successfully registered at %s\n"), system);

	while(serverHandle != NULL){
		int refresh = 0;

		rc = RfcListenAndDispatch(serverHandle, 5, &errorInfo);
		switch (rc){
			case RFC_RETRY:
				break;
			case RFC_ABAP_EXCEPTION:
				printfU(cU("ABAP_EXCEPTION in implementing function: %s\n"), errorInfo.key);
				break;
			case RFC_NOT_FOUND:
				printfU(cU("Unknown function module: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_EXTERNAL_FAILURE:
				printfU(cU("SYSTEM_FAILURE has been sent to backend: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_ABAP_MESSAGE:
				printfU(cU("ABAP Message has been sent to backend: %s %s %s\n"), errorInfo.abapMsgType,
							errorInfo.abapMsgClass, errorInfo.abapMsgNumber);
				printfU(cU("Variables: V1=%s V2=%s V3=%s V4=%s\n"), errorInfo.abapMsgV1,
							errorInfo.abapMsgV2, errorInfo.abapMsgV3, errorInfo.abapMsgV4);
				refresh = 1;
				break;
			case RFC_CLOSED:
			case RFC_COMMUNICATION_FAILURE:
				printfU(cU("Communication Failure: %s\n"), errorInfo.message);
				refresh = 1;
				break;
		}
		if (refresh){
			serverHandle = RfcRegisterServer(gatewayParams, 1, &errorInfo);
			if (serverHandle == NULL){
				printfU(cU("Unable to reconnect to %s: %s: %s\n"), system,
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				printfU(cU("Stopping to listen at %s"), system);
			}
		}
		if (!listening) break;
	}

	if (serverHandle != NULL) RfcCloseConnection(serverHandle, NULL);

	return 0;
}