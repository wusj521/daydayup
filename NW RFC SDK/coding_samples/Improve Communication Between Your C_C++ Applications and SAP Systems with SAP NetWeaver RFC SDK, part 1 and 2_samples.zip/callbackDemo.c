#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "sapnwrfc.h"

static int listening = 1;
static RFC_FUNCTION_HANDLE bapiUserGetDetail;

RFC_RC SAP_API stfcConnection(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc = RFC_OK;
	unsigned length;
	SAP_UC requtext[256], resptext[256], echotext[256];
	RFC_ATTRIBUTES attributes;
	RFC_STRUCTURE_HANDLE address, company;

	RfcGetString(funcHandle, cU("REQUTEXT"), requtext, 256, &length, NULL);
	printfU(cU("\nReceived request for STFC_CONNECTION\n"));
	printfU(cU("REQUTEXT = %s\n"), requtext);

	RfcGetConnectionAttributes(rfcHandle, &attributes, NULL);
	printfU(cU("User is %s. Let's see what we can find out about him/her.\n"), attributes.user);

	RfcSetString(bapiUserGetDetail, cU("USERNAME"), attributes.user, strlenU(attributes.user), NULL);
	RfcGetStructure(bapiUserGetDetail, cU("ADDRESS"), &address, NULL);
	RfcSetString(address, cU("FULLNAME"), cU(" "), 1, NULL);
	RfcGetStructure(bapiUserGetDetail, cU("COMPANY"), &company, NULL);
	RfcSetString(company, cU("COMPANY"), cU(" "), 1, NULL);

	rc = RfcInvoke(rfcHandle, bapiUserGetDetail, errorInfo);
	if (rc != RFC_OK){
		strncpyU(echotext, cU("Unfortunately calling BAPI_USER_GET_DETAIL failed:"), 50);
		strncpyU(resptext, errorInfo->message, strlenU(errorInfo->message));
		errorInfo->message[0] = 0;
		errorInfo->code = RFC_OK;
	}
	else{
		strncpyU(echotext, cU("Hi, you are "), 12);
		RfcGetStructure(bapiUserGetDetail, cU("ADDRESS"), &address, NULL);
		RfcGetString(address, cU("FULLNAME"), echotext+12, 244, &length, NULL);
		strncpyU(resptext, cU("Your company is "), 16);
		RfcGetStructure(bapiUserGetDetail, cU("COMPANY"), &company, NULL);
		RfcGetString(company, cU("COMPANY"), resptext+16, 241, &length, NULL);
	}
	RfcSetString(funcHandle, cU("RESPTEXT"), resptext, strlenU(resptext), NULL);
	RfcSetString(funcHandle, cU("ECHOTEXT"), echotext, strlenU(echotext), NULL);

	printfU(cU("Do you want to stop listening after this request? [y/n] "));
	getsU(requtext);
	if (*requtext == cU('y')) listening = 0;

	return RFC_OK;
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_PARAMETER loginParams[1];
	RFC_CONNECTION_HANDLE connection;
	RFC_ATTRIBUTES attributes;
	RFC_FUNCTION_DESC_HANDLE desc1, desc2;
	SAP_UC* system = cU("SPJ_REG");

	loginParams->name = cU("dest");	loginParams->value = cU("SPJ");

	connection = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n"), errorInfo.message);
		printfU(cU("Please check that the sapnwrfc.ini file is in the current\nworking directory and the logon parameters are ok.\n"));
		return 1;
	}

	rc = RfcGetConnectionAttributes(connection, &attributes, NULL);
	if (rc == RFC_OK)
		printfU(cU("Successfully logged on to destination SPJ (System-ID %s)\n"), attributes.sysId);

	desc1 = RfcGetFunctionDesc(connection, cU("STFC_CONNECTION"), &errorInfo);
	desc2 = RfcGetFunctionDesc(connection, cU("BAPI_USER_GET_DETAIL"), &errorInfo);
	RfcCloseConnection(connection, NULL);
	if (desc1 == NULL || desc2 == NULL){
		printfU(cU("Error getting metadata: %s\n"), errorInfo.message);
		return 1;
	}

	rc = RfcInstallServerFunction(NULL, desc1, stfcConnection, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Unable to install RequestHandler: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	bapiUserGetDetail = RfcCreateFunction(desc2, &errorInfo);
	if (bapiUserGetDetail == NULL){
		printfU(cU("Error creating data container: %s\n"), errorInfo.message);
		return 1;
	}

	loginParams->value = system;
	connection = RfcRegisterServer(loginParams, 1, &errorInfo);
	if (connection == NULL) printfU(cU("Unable to register at %s: %s: %s\n"), system,
								RfcGetRcAsString(errorInfo.code), errorInfo.message);
	else printfU(cU("Successfully registered at %s\n"), system);

	while(connection != NULL){
		int refresh = 0;

		rc = RfcListenAndDispatch(connection, 5, &errorInfo);
		switch (rc){
			case RFC_RETRY:
				break;
			case RFC_ABAP_EXCEPTION:
				printfU(cU("ABAP_EXCEPTION in implementing function: %s\n"), errorInfo.key);
				break;
			case RFC_NOT_FOUND:
				printfU(cU("Unknown function module: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_EXTERNAL_FAILURE:
				printfU(cU("SYSTEM_FAILURE has been sent to backend: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_ABAP_MESSAGE:
				printfU(cU("ABAP Message has been sent to backend: %s %s %s\n"), errorInfo.abapMsgType,
							errorInfo.abapMsgClass, errorInfo.abapMsgNumber);
				printfU(cU("Variables: V1=%s V2=%s V3=%s V4=%s\n"), errorInfo.abapMsgV1,
							errorInfo.abapMsgV2, errorInfo.abapMsgV3, errorInfo.abapMsgV4);
				refresh = 1;
				break;
			case RFC_CLOSED:
			case RFC_COMMUNICATION_FAILURE:
				printfU(cU("Communication Failure: %s\n"), errorInfo.message);
				refresh = 1;
				break;
		}
		if (refresh){
			connection = RfcRegisterServer(loginParams, 1, &errorInfo);
			if (connection == NULL){
				printfU(cU("Unable to reconnect to %s: %s: %s\n"), system,
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				printfU(cU("Stopping to listen at %s"), system);
			}
		}
		if (!listening) break;
	}

	if (connection != NULL) RfcCloseConnection(connection, NULL);

	return 0;
}