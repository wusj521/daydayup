#include "sapnwrfc.h"

typedef enum _StoreRC{
	RC_OK,
	IOError,
	OutOfMemory,
	InvalidParameter,
	NotFound,
	AlreadyExisting
} StoreRC;

typedef enum _TIDStatus{
	Status_Created,
	Status_Executed,
	Status_Committed,
	Status_RolledBack,
	Status_Confirmed
}TIDStatus;

void convertToNUMC(unsigned number, SAP_UC* numc);

/*	Opens a TID Store file and reads its contents into an "index".
	If the file does not yet exist, a new TID Store is created. */
StoreRC openTIDStore(char* fileName, void** tidStore);

/*	Closes the corresponding TID Store file and releases the associated memory. */
void closeTIDStore(void* tidStore);

/*	Either creates a new entry for the given TID or returns the existing entry,
	if that TID is already known. In either case an index to that entry is returned,
	which has to be used in the following functions for changing the entry.
	The return code is RC_OK or AlreadyExisting, depending on whether a new entry
	was created or an existing one was found.
	If you have a unique DOCNUM, but no TID yet, you can also use this function to
	create an entry with an initial TID. Pass tid = NULL in this case and use the
	function setTID() lateron, once you have a TID for that IDoc.
	The function can also be used to set a DOCNUM on an existing entry. */
StoreRC getEntry(void* tidStore, char* tid, char* docnum, unsigned* index);

/*	The following should be self-explanatory. */
StoreRC deleteEntry(void* tidStore, unsigned index);
StoreRC getTIDStatus(void* tidStore, unsigned index, TIDStatus* tidStatus);
StoreRC setTIDStatus(void* tidStore, unsigned index, TIDStatus tidStatus, char* errorMessage);
StoreRC setTID(void* tidStore, unsigned index, char* tid);

/*	Returns TID and DOCNUM for a given index. */
StoreRC getDetails(void* tidStore, unsigned index, char* tid, char* docnum);

/*	Returns the detail error message for a given index. */
StoreRC getErrorMessage(void* tidStore, unsigned index, char* errorMessage);

/*	Returns the number and the indices of all entries, which currently still have an
	initial TID. */
StoreRC getInitialEntries(void* tidStore, unsigned* numEntries, unsigned** indices);

/*	Prints all details for a given entry to the console. */
StoreRC printEntry(void* tidStore, unsigned index);

/*	Prints a list of all existing entries to the console. */
StoreRC overView(void* tidStore);

/*	The functions can be used to persist the payload of an IDoc to disc and
	read/delete it again. In all three cases the function handle must be of
	type IDOC_INBOUND_ASYNCHRONOUS and the DOCNUM of the control header must be
	filled, as that is used as the key for the IDoc files. */
StoreRC saveMessageBody(RFC_FUNCTION_HANDLE iDoc);
StoreRC readMessageBody(RFC_FUNCTION_HANDLE iDoc);
StoreRC deleteMessageBody(RFC_FUNCTION_HANDLE iDoc);