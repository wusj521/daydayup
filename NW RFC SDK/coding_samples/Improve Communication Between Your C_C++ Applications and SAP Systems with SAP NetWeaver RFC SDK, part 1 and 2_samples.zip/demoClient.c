#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"

// Defined in helperFunctions.c
extern void readValue(SAP_UC* buffer, int max);
extern int userSaysYes(void);
extern void fillParameter(int* index, RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container);
extern void printParameter(RFC_PARAMETER_DESC desc, RFC_FUNCTION_HANDLE container);

void checkForReset(RFC_CONNECTION_HANDLE conn){
	printfU(cU("Do you want to reset the ABAP session? [y/n] "));
	if (userSaysYes()) RfcResetServerContext(conn, NULL);
}

void fillImports(RFC_FUNCTION_DESC_HANDLE description, RFC_FUNCTION_HANDLE container){
	unsigned i, parameterCount;
	RFC_PARAMETER_DESC paramDesc;

	RfcGetParameterCount(description, &parameterCount, NULL);
	
	printfU(cU("Please enter the IMPORTING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_IMPORT){
			fillParameter(&i, paramDesc, container);
		}
	}

	printfU(cU("\nPlease enter the CHANGING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_CHANGING){
			fillParameter(&i, paramDesc, container);
		}
	}

	printfU(cU("\nPlease enter the TABLES parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_TABLES){
			fillParameter(&i, paramDesc, container);
		}
	}
}

void printExports(RFC_FUNCTION_DESC_HANDLE description, RFC_FUNCTION_HANDLE container){
	unsigned i, parameterCount;
	RFC_PARAMETER_DESC paramDesc;

	RfcGetParameterCount(description, &parameterCount, NULL);
	
	printfU(cU("Here are the results of the EXPORTING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_EXPORT){
			printParameter(paramDesc, container);
		}
	}

	printfU(cU("\nHere are the results of the CHANGING parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_CHANGING){
			printParameter(paramDesc, container);
		}
	}

	printfU(cU("\nHere are the results of the TABLES parameters:\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(description, i, &paramDesc, NULL);
		if (paramDesc.direction == RFC_TABLES){
			printParameter(paramDesc, container);
		}
	}
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_CONNECTION_PARAMETER loginParams[1];
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_HANDLE connection;
	RFC_ATTRIBUTES attributes;
	RFC_FUNCTION_DESC_HANDLE functionDescription;
	RFC_FUNCTION_HANDLE functionContainer;
	RFC_ABAP_NAME functionName;

	loginParams[0].name = cU("dest");	loginParams[0].value = cU("SPJ");

	connection = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n"), errorInfo.message);
		printfU(cU("Please check that the sapnwrfc.ini file is in the current\nworking directory and the logon parameters are ok.\n"));
		return 1;
	}

	rc = RfcGetConnectionAttributes(connection, &attributes, NULL);
	if (rc == RFC_OK)
		printfU(cU("Successfully logged on to destination SPJ (System-ID %s)\n"), attributes.sysId);

	while (1){
		printfU(cU("\nPlease enter the name of a function module (or x to exit):\n> "));
		readValue(functionName, 31);
		if (strcmpU(functionName, cU("x")) == 0) break;

		functionDescription = RfcGetFunctionDesc(connection, functionName, &errorInfo);
		if (functionDescription == NULL){
			printfU(cU("Unable to obtain description for function module %s.\n%s: %s\n"),
				functionName, RfcGetRcAsString(errorInfo.code),
				errorInfo.code==RFC_ABAP_EXCEPTION?errorInfo.key:errorInfo.message);
			if (errorInfo.code == RFC_COMMUNICATION_FAILURE) break; //Looks like connection broke down in the meantime.
			else continue;
		}

		functionContainer = RfcCreateFunction(functionDescription, &errorInfo);
		if (functionContainer == NULL){ //Probably out of memory?!
			printfU(cU("Unable to create data container for function module %s.\n%s: %s\n"),
				functionName, RfcGetRcAsString(errorInfo.code), errorInfo.message);
			continue;
		}

		printfU(cU("\n"));
		fillImports(functionDescription, functionContainer);

		printfU(cU("\n"));
		rc = RfcInvoke(connection, functionContainer, &errorInfo);
		switch(rc){
			case RFC_OK:
				printExports(functionDescription, functionContainer);
				checkForReset(connection);
				break;
			case RFC_ABAP_EXCEPTION:
				printfU(cU("%s threw an ABAP Exception: %s\n"), functionName, errorInfo.key);
				if (strlenU(errorInfo.abapMsgClass) > 0)  //This takes care of the "MESSAGE ... RAISING ..." case.
					printfU(cU("Message Details: TYPE=%s ID=%s NO=%s V1=%s V2=%s V3=%s V4=%s\n"),
								errorInfo.abapMsgType,
								errorInfo.abapMsgClass,
								errorInfo.abapMsgNumber,
								errorInfo.abapMsgV1,
								errorInfo.abapMsgV2,
								errorInfo.abapMsgV3,
								errorInfo.abapMsgV4
					);
				checkForReset(connection);
				break;
			case RFC_ABAP_MESSAGE:
				printfU(cU("%s threw an ABAP Message: %s\n"), functionName, errorInfo.message);
				printfU(cU("Message Details: TYPE=%s ID=%s NO=%s V1=%s V2=%s V3=%s V4=%s\n"),
							errorInfo.abapMsgType,
							errorInfo.abapMsgClass,
							errorInfo.abapMsgNumber,
							errorInfo.abapMsgV1,
							errorInfo.abapMsgV2,
							errorInfo.abapMsgV3,
							errorInfo.abapMsgV4
				);
				connection = RfcOpenConnection(loginParams, 1, &errorInfo);
				rc = errorInfo.code;
				break;
			case RFC_ABAP_RUNTIME_FAILURE:
				printfU(cU("%s aborted with a SYSTEM_FAILURE: %s: %s\n"), functionName,
							errorInfo.key, errorInfo.message);
				connection = RfcOpenConnection(loginParams, 1, &errorInfo);
				rc = errorInfo.code;
				break;
		}
		RfcDestroyFunction(functionContainer, NULL);

		/* The following if-block handles both cases: when the connection broke down during RfcInvoke
		   as well as when we were unable to re-connect after an RFC_ABAP_MESSAGE or RFC_ABAP_RUNTIME_FAILURE.
		   That's why I didn't include this case in the switch-block.
		*/
		if (rc == RFC_COMMUNICATION_FAILURE){
			printfU(cU("A communication/network problem occured: %s\n"), errorInfo.message);
			printfU(cU("Please check the connection to %s and try again.\n"), attributes.sysId);
			break;
		}
	}

	if (connection != NULL) RfcCloseConnection(connection, NULL);
	return 0;
}