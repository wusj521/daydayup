#include "sapnwrfc.h"

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	RFC_CONNECTION_PARAMETER loginParams[6];
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_HANDLE connection;
	RFC_FUNCTION_DESC_HANDLE functionDesc;
	RFC_PARAMETER_DESC paramDesc;
	RFC_EXCEPTION_DESC excepDesc;
	RFC_FIELD_DESC fieldDesc;
	RFC_ABAP_NAME typeName;
	unsigned parameterCount = 0, fieldCount = 0, i, j;

	loginParams[0].name = cU("ashost");	loginParams[0].value = cU("binmain");
	loginParams[1].name = cU("sysnr");	loginParams[1].value = cU("53");
	loginParams[2].name = cU("client");	loginParams[2].value = cU("000");
	loginParams[3].name = cU("user");	loginParams[3].value = cU("SCHMIDTUL");
	loginParams[4].name = cU("lang");	loginParams[4].value = cU("DE");
	loginParams[5].name = cU("passwd");	loginParams[5].value = cU("hd955wdd");

	connection = RfcOpenConnection(loginParams, 6, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n%s: %s\n"), RfcGetRcAsString(errorInfo.code),
			errorInfo.key, errorInfo.message);
		return 1;
	}

	functionDesc = RfcGetFunctionDesc(connection, cU("W3_GET_MINIAPP_TEXTS"), &errorInfo);
	RfcCloseConnection(connection, NULL);

	// Note: W3_GET_MINIAPP_TEXTS only exists starting with R/3 Release 4.6C
	if (functionDesc == NULL){
		printfU(cU("Error during metadata lookup: %s\n%s: %s\n"), RfcGetRcAsString(errorInfo.code),
			errorInfo.key, errorInfo.message);
		return 1;
	}

	RfcGetParameterCount(functionDesc, &parameterCount, NULL);
	
	printfU(cU("Name\t\t\tDirection\t\tType\t\tNon-UC Length\t\tUC Length\t\tStructure\n"));
	printfU(cU("-----------------------------------------------------------------------------------------------------------------\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetParameterDescByIndex(functionDesc, i, &paramDesc, NULL);
		printfU(cU("%s\t\t%s\t\t%s\t\t%d\t\t%d\t\t"),
			paramDesc.name,
			RfcGetDirectionAsString(paramDesc.direction),
			RfcGetTypeAsString(paramDesc.type),
			paramDesc.nucLength,
			paramDesc.ucLength
		);
		if (paramDesc.typeDescHandle == NULL) printfU(cU("\n"));
		else{
			RfcGetTypeName(paramDesc.typeDescHandle, typeName, NULL);
			printfU(cU("%s\n"), typeName);
			RfcGetFieldCount(paramDesc.typeDescHandle, &fieldCount, NULL);
			printfU(cU("\n                             -----------( Structure of %s )-----------\n"), typeName);
			for (j=0; j<fieldCount; j++){
				RfcGetFieldDescByIndex(paramDesc.typeDescHandle, j, &fieldDesc, NULL);
				printfU(cU("\t%s   \t\t\t\t%s\t\t%d\t\t%d\n"),
					fieldDesc.name,
					RfcGetTypeAsString(fieldDesc.type),
					fieldDesc.nucLength,
					fieldDesc.ucLength
				);
			}
			printfU(cU("\n                             -----------( Structure of %s )-----------\n"), typeName);
		}
	}

	RfcGetExceptionCount(functionDesc, &parameterCount, NULL);
	
	printfU(cU("\nExceptions\n----------\n"));
	for (i=0; i<parameterCount; i++){
		RfcGetExceptionDescByIndex(functionDesc, i, &excepDesc, NULL);
		printfU(cU("%s    \t\t%s\n"), excepDesc.key, excepDesc.message);
	}

	return 0;
}