#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "statusTracking.h"

void* tidStore;
int listening = 1;
char tidC_local[25]; /* Note: for a multithreaded tRFC server, this needs to be kept in thread local storage!
					 unfortunately RFC_SERVER_FUNCTION doesn't give us the TID as RFC_ON_..._TRANSACTION do. */


RFC_RC SAP_API onExecute(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo){
	RFC_RC rc;
	StoreRC src;
	RFC_TABLE_HANDLE table;
	char docnumC[17];
	SAP_UC sdata[1064];
	SAP_UC idocType[31];
	unsigned i, index, tidEntry;

	/* onCheckTID() is called in the same thread right before onExecute(). So if tidC is empty,
	this means we have been called by synchronous RFC instead of tRFC. Don't allow this... 
	in the following we always need to clear tidC, before leaving onExecute(), so as not to
	leave old TIDs lying around, which may confuse a later "synchronous" onExecute(). */
	if (*tidC_local == 0){
		strncpyU(errorInfo->message, cU("Can't execute IDocs via synchronous RFC"), 39);
		errorInfo->code = RFC_EXTERNAL_FAILURE;
		return RFC_EXTERNAL_FAILURE;
	}

	printf("Executing TID %s\n", tidC_local);

	rc = RfcGetTable(funcHandle, cU("IDOC_CONTROL_REC_40"), &table, errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting Control Record: %s"), errorInfo->message);
		*tidC_local = 0;
		return RFC_EXTERNAL_FAILURE;
	}

	/* Note: this server can handle only single IDocs. For "IDoc Packets" you would need to
	loop over the lines of IDOC_CONTROL_REC_40 and for each DOCNUM find the corresponding
	entries in IDOC_DATA_REC_40 with that DOCNUM. */
	if (RfcMoveToFirstRow(table, NULL) == RFC_OK){
		RfcGetString(table, cU("DOCNUM"), sdata, 17, &index, NULL);
		RfcGetString(table, cU("IDOCTYP"), idocType, 31, &index, NULL);
		printfU(cU("Processing IDoc %s of type %s\n"), sdata, idocType);
	}
	else{
		printfU(cU("IDoc is empty\n"));
		*tidC_local = 0;
		return RFC_OK;
	}

	index = 17;
	RfcSAPUCToUTF8(sdata,  16, docnumC, &index, &i, NULL);
	src = getEntry(tidStore, tidC_local, docnumC, &tidEntry);

	if (src != AlreadyExisting){
		printfU(cU("Error in status management\n"));
		strncpyU(errorInfo->message, cU("Error in status management"), 26);
		errorInfo->code = RFC_EXTERNAL_FAILURE;
		*tidC_local = 0;
		return RFC_EXTERNAL_FAILURE;

	}

	rc = RfcGetTable(funcHandle, cU("IDOC_DATA_REC_40"), &table, errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting Data Records: %s"), errorInfo->message);
		*tidC_local = 0;
		setTIDStatus(tidStore, tidEntry, Status_RolledBack, "Error getting Data Records");
		return RFC_EXTERNAL_FAILURE;
	}

	rc = RfcMoveToFirstRow(table, NULL);
	while (rc == RFC_OK){
		RfcGetString(table, cU("SDATA"), sdata, 1064, &index, NULL);
		printfU(cU("%s\n"), sdata);
		rc = RfcMoveToNextRow(table, NULL);
	}

	printfU(cU("Do you want to rollback the IDoc with an error message? [y/n] "));
	getsU(sdata);
	if (*sdata == cU('y')){
		char buffer[1024];
		printfU(cU("Please enter an error message: "));
		getsU(sdata);
		index = strlenU(sdata);
		if (index > 512) index = 512;
		i = 1024;
		RfcSAPUCToUTF8(sdata,  index, buffer, &i,  &i, NULL);
		strncpyU(errorInfo->message, sdata, index);
		setTIDStatus(tidStore, tidEntry, Status_RolledBack, buffer);
		errorInfo->code = RFC_EXTERNAL_FAILURE;
		return RFC_EXTERNAL_FAILURE;
	}

	setTIDStatus(tidStore, tidEntry, Status_Executed, " ");
	return RFC_OK;
}

RFC_RC SAP_API onCheckTID(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid){
	StoreRC rc;
	unsigned index = 25;
	TIDStatus status;

	printfU(cU("\n\nChecking TID %s\n"), tid);
	RfcSAPUCToUTF8(tid,  24, tidC_local, &index,  NULL, NULL);
	rc = getEntry(tidStore, tidC_local, NULL, &index);

	switch (rc){
		case AlreadyExisting:
			rc = getTIDStatus(tidStore, index, &status);
			if (rc == RC_OK){
				if (status == Status_Created || status == Status_RolledBack) return RFC_OK;
				return RFC_EXECUTED;
			}
			return RFC_EXTERNAL_FAILURE;
		case RC_OK:
			return RFC_OK;
		default:
			return RFC_EXTERNAL_FAILURE;
	}
}

RFC_RC SAP_API onCommit(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid){
	StoreRC rc;
	unsigned index = 25;
	char tidC[25];

	printfU(cU("Committing TID %s\n"), tid);
	RfcSAPUCToUTF8(tid,  24, tidC, &index,  NULL, NULL);
	rc = getEntry(tidStore, tidC, NULL, &index);
	if (rc == AlreadyExisting) setTIDStatus(tidStore, index, Status_Committed, NULL);

	/* At this point we know, that the IDoc has already been executed successfully.
	So we return RFC_OK in any case, even if accessing the tidStore above failed.
	Any errors are irrelevant at this stage. */
	return RFC_OK;
}

RFC_RC SAP_API onRollback(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid){
	StoreRC rc;
	unsigned index = 25;
	char tidC[25];

	printfU(cU("Rolling back TID %s\n"), tid);
	RfcSAPUCToUTF8(tid,  24, tidC, &index,  NULL, NULL);
	rc = getEntry(tidStore, tidC, NULL, &index);
	if (rc == AlreadyExisting) setTIDStatus(tidStore, index, Status_RolledBack, NULL);

	return RFC_OK;
}

RFC_RC SAP_API onConfirm(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid){
	StoreRC rc;
	unsigned index = 25;
	char tidC[25];

	printfU(cU("Confirming TID %s\n"), tid);
	RfcSAPUCToUTF8(tid,  24, tidC, &index,  NULL, NULL);
	rc = getEntry(tidStore, tidC, NULL, &index);
	deleteEntry(tidStore, index);

	printfU(cU("Do you want to stop listening after this request? [y/n] "));
	gets(tidC);
	if (*tidC == 'y') listening = 0;

	return RFC_OK;
}

int mainU(int argc, SAP_UC** argv){
	RFC_RC rc = RFC_OK;
	StoreRC store_rc;
	RFC_ERROR_INFO errorInfo;
	RFC_CONNECTION_PARAMETER loginParams[1];
	RFC_CONNECTION_HANDLE connection;
	RFC_FUNCTION_DESC_HANDLE iDocInboundDesc = NULL;
	RFC_ATTRIBUTES attributes;
	int error = 0;

	loginParams[0].name = cU("dest");	loginParams[0].value = cU("SPJ");

	connection = RfcOpenConnection(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Error during logon: %s\n"), errorInfo.message);
		printfU(cU("Please check that the sapnwrfc.ini file is in the current\nworking directory and the logon parameters are ok.\n"));
		return 1;
	}

	rc = RfcGetConnectionAttributes(connection, &attributes, NULL);
	if (rc == RFC_OK)
		printfU(cU("Successfully logged on to destination SPJ (System-ID %s)\n"), attributes.sysId);

	iDocInboundDesc = RfcGetFunctionDesc(connection, cU("IDOC_INBOUND_ASYNCHRONOUS"), &errorInfo);
	RfcCloseConnection(connection, NULL);
	if (iDocInboundDesc == NULL){
		printfU(cU("Error getting metadata: %s\n"), errorInfo.message);
		return 1;
	}

	rc = RfcInstallServerFunction(NULL, iDocInboundDesc, onExecute, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Unable to install RequestHandler: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	rc = RfcInstallTransactionHandlers(NULL, onCheckTID, onCommit, onRollback, onConfirm, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Unable to install TransactionHandlers: %s: %s\n"), RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}

	loginParams[0].value = cU("SPJ_REG");
	connection = RfcRegisterServer(loginParams, 1, &errorInfo);
	if (connection == NULL){
		printfU(cU("Unable to register at %s: %s: %s\n"), loginParams[0].value, RfcGetRcAsString(errorInfo.code), errorInfo.message);
		return 1;
	}
	else printfU(cU("Successfully registered at %s\n"), loginParams[0].value);

	store_rc = openTIDStore("idoc_server_store", &tidStore);
	if (store_rc != RC_OK){
		RfcCloseConnection(connection, NULL);
		return 1;
	}

	while(connection != NULL){
		int refresh = 0;

		rc = RfcListenAndDispatch(connection, 50, &errorInfo);
		switch (rc){
			case RFC_NOT_FOUND:
				printfU(cU("Unknown function module: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_EXTERNAL_FAILURE:
			case RFC_CLOSED: /* tRFC behaves slightly different here than synchronous RFC:
				a SYSTEM_FAILURE can also be indicated by RFC_CLOSED... 
				In a synchronous RFC server I would treat RFC_CLOSED and RFC_COMMUNICATION_FAILURE
				within the same case. */
				printfU(cU("SYSTEM_FAILURE has been sent to backend: %s\n"), errorInfo.message);
				refresh = 1;
				break;
			case RFC_ABAP_MESSAGE:
				printfU(cU("ABAP Message has been sent to backend: %s %s %s\n"), errorInfo.abapMsgType,
							errorInfo.abapMsgClass, errorInfo.abapMsgNumber);
				printfU(cU("Variables: V1=%s V2=%s V3=%s V4=%s\n"), errorInfo.abapMsgV1,
							errorInfo.abapMsgV2, errorInfo.abapMsgV3, errorInfo.abapMsgV4);
				refresh = 1;
				break;
			case RFC_COMMUNICATION_FAILURE:
				printfU(cU("Communication Failure: %s\n"), errorInfo.message);
				refresh = 1;
				break;
		}
		if (refresh){
			connection = RfcRegisterServer(loginParams, 1, &errorInfo);
			if (connection == NULL){
				printfU(cU("Unable to reconnect to %s: %s: %s\n"), attributes.sysId,
						RfcGetRcAsString(errorInfo.code), errorInfo.message);
				printfU(cU("Stopping to listen at %s"), attributes.sysId);
				error = 1;
			}
		}
		if (!listening) break;
	}

	if (connection != NULL) RfcCloseConnection(connection, NULL);
	closeTIDStore(tidStore);
	return error;
}