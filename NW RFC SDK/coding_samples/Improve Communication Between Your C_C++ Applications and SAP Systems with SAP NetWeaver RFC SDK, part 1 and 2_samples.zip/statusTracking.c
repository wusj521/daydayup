#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <memory.h>
#include <string.h>
#include "statusTracking.h"

#define ENTRY_SIZE 121
// TID		24
// DOCNUM	16
// Status	 1
// Error	80
char* INITIAL = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

typedef struct _Link{
	unsigned index;
	unsigned fileIndex;
	void* next;
} Link;

typedef struct _StoreEntry{
	char tid[24];
	unsigned index;
} StoreEntry;

typedef struct _TIDStore{
	FILE* file;
	StoreEntry* table;
	Link* freeEntry;
	unsigned end;
	unsigned length;
	unsigned initials;
} TIDStore;

int tidEquals(char* tid1, char* tid2){
	int i = 0;
	while (i++<24) if (*(tid1++) != *(tid2++)) return 0;
	return 1;
}

void convertToNUMC(unsigned number, SAP_UC* numc){
	unsigned i=15;
	for (i=0; i<16; i++) numc[i] = cU('0');

	i = 15;
	while (number && i>=0){
		switch(number%10){
			case 1: numc[i] = cU('1'); break;
			case 2: numc[i] = cU('2'); break;
			case 3: numc[i] = cU('3'); break;
			case 4: numc[i] = cU('4'); break;
			case 5: numc[i] = cU('5'); break;
			case 6: numc[i] = cU('6'); break;
			case 7: numc[i] = cU('7'); break;
			case 8: numc[i] = cU('8'); break;
			case 9: numc[i] = cU('9'); break;
		}
		number /= 10;
		i--;
	}
}

int appendEntry(TIDStore* store, char* tid){
	int index;
	size_t size;
	if (store->end == store->length){
		StoreEntry* temp;
		index = store->length + 10;
		temp = (StoreEntry*)realloc(store->table, sizeof(StoreEntry)*index);
		if (temp == NULL) return -1;
		store->table = temp;
		store->length = index;
	}

	index = store->end++;
	memcpy(store->table[index].tid, tid, 24);
	store->table[index].index = sizeof(unsigned) + index * ENTRY_SIZE;

	rewind(store->file);
	size = fwrite(&(store->end), sizeof(unsigned), 1, store->file);
	if (size != 1) return -1;
	if (fseek(store->file, store->table[index].index, SEEK_SET)) return -1;
	size = fwrite(tid, sizeof(char), 24, store->file);
	if (size != 24) return -1;
	fflush(store->file);

	return index;
}

StoreRC openTIDStore(char* fileName, void** tidStore){
	TIDStore* store;
	size_t size;
	unsigned i;
	Link* link, *temp;
	StoreRC rc = OutOfMemory;

	store = (TIDStore*)malloc(sizeof(TIDStore));
	if (store == NULL) return OutOfMemory;

	store->end = 0;
	store->initials = 0;
	store->table = NULL;
	store->freeEntry = NULL;
	store->file = fopen(fileName, "r+");
	if (store->file == NULL){
		if (errno == ENOENT){ //File does not yet exist. Try to create a new one.
			store->file = fopen(fileName, "w+");
			if (store->file != NULL){
				size = fwrite(&(store->end), sizeof(unsigned), 1, store->file);
				if (size == 1){
					fflush(store->file);
					goto success;
				}
			}
		}
		goto ioerror;
	}
	else{
		size = fread(&(store->end), sizeof(unsigned), 1, store->file);
		if (size == 0) goto ioerror;
	}

	success:
	store->length = 10 + store->end;
	store->table = (StoreEntry*)malloc(store->length*sizeof(StoreEntry));
	if (store->table == NULL) goto error;

	for (i=0; i<store->end; i++){
		size = fread(store->table[i].tid, sizeof(char), 24, store->file);
		if (size != 24) goto ioerror;
		store->table[i].index = sizeof(unsigned) + i*ENTRY_SIZE;
		if (store->table[i].tid[0] == 1){
			link = (Link*)malloc(sizeof(Link));
			if (link == NULL) goto error;
			link->index = i;
			link->fileIndex = store->table[i].index;
			link->next = store->freeEntry;
			store->freeEntry = link;
		}
		else if (store->table[i].tid[0] == 0) store->initials++;
		fseek(store->file, ENTRY_SIZE-24, SEEK_CUR);
	}
	*tidStore = store;
	return RC_OK;

	ioerror:
	perror("IO Error: ");
	rc = IOError;
	error:
	if (store->file != NULL) fclose(store->file);
	if (store->table != NULL) free(store->table);
	link = store->freeEntry;
	while (link != NULL){
		temp = (Link*)link->next;
		free(link);
		link = temp;
	}
	free(store);
	return rc;
}

void closeTIDStore(void* tidStore){
	Link* link, *temp;
	TIDStore* store = (TIDStore*)tidStore;
	fclose(store->file);
	free(store->table);
	link = store->freeEntry;
	while (link != NULL){
		temp = (Link*)link->next;
		free(link);
		link = temp;
	}
	free(store);
}

StoreRC getEntry(void* tidStore, char* tid, char* docnum, unsigned* index){
	int i;
	unsigned writeIndex, tabIndex;
	TIDStore* store = (TIDStore*)tidStore;

	if (tid == NULL){
		if (docnum == NULL) return InvalidParameter;
		tid = INITIAL;
		store->initials++;
	}
	else{
		for (tabIndex=0; tabIndex<store->end; tabIndex++){
			if (tidEquals(tid, store->table[tabIndex].tid)){
				if (docnum != NULL){
					if (fseek(store->file, store->table[tabIndex].index + 24, SEEK_SET)){
						perror("IO Error: ");
						return IOError;
					}
					if (fwrite(docnum, sizeof(char), 16, store->file) != 16){
						perror("IO Error: ");
						return IOError;
					}
				}
				*index = tabIndex;
				return AlreadyExisting;
			}
		}
	}

	if (store->freeEntry != NULL){
		*index = store->freeEntry->index;
		writeIndex = store->freeEntry->fileIndex;
		memcpy(store->table[*index].tid, tid, 24);
	}
	else{
		i = appendEntry(store, tid);
		if (i == -1) return OutOfMemory;
		*index = i;
		writeIndex = store->table[i].index;
	}

	if (fseek(store->file, writeIndex, SEEK_SET)){
		perror("IO Error: ");
		return IOError;
	}

	if (fwrite(tid, sizeof(char), 24, store->file) != 24){
		perror("IO Error: ");
		return IOError;
	}
	if (docnum == NULL){
		for (i=0; i<16; i++) if (fputc(48, store->file) == EOF){
			perror("IO Error: ");
			return IOError;
		}
	}
	else{
		if (fwrite(docnum, sizeof(char), 16, store->file) != 16){
			perror("IO Error: ");
			return IOError;
		}
	}
	if (fputc(Status_Created, store->file) == EOF){
		perror("IO Error: ");
		return IOError;
	}
	for (i=0; i<80; i++) if (fputc(32, store->file) == EOF){
		perror("IO Error: ");
		return IOError;
	}
	fflush(store->file);

	if (store->freeEntry != NULL){ // We have reused an existing entry. Remove it from our "pool".
		Link* temp = store->freeEntry;
		store->freeEntry = (Link*)temp->next;
		free(temp);
	}
	return RC_OK;
}

StoreRC getTIDStatus(void* tidStore, unsigned index, TIDStatus* tidStatus){
	TIDStore* store = (TIDStore*)tidStore;
	int result;

	if (index >= store->end) return InvalidParameter;

	if (fseek(store->file, store->table[index].index + 40, SEEK_SET)){
		perror("Error getting TID status: ");
		return IOError;
	}

	result = fgetc(store->file);
	if (result == EOF){
		perror("Error getting TID status: ");
		return IOError;
	}
	*tidStatus = result;
	return RC_OK;
}

StoreRC setTIDStatus(void* tidStore, unsigned index, TIDStatus tidStatus, char* errorMessage){
	TIDStore* store = (TIDStore*)tidStore;
	size_t result;

	if (index >= store->end) return InvalidParameter;

	if (fseek(store->file, store->table[index].index + 40, SEEK_SET)){
		perror("Error setting TID status: ");
		return IOError;
	}
	if (fputc(tidStatus, store->file) == EOF){
		perror("Error setting TID status: ");
		return IOError;
	}

	if (errorMessage != NULL){
		unsigned i;
		result = strlen(errorMessage);
		if (result > 80) result = 80;
		for (i=0; i<result; i++) if (errorMessage[i] == 13 || errorMessage[i] == 10) errorMessage[i] = 32;
		fwrite(errorMessage, sizeof(char), result, store->file);
		if (result < 80) fputc(0, store->file);
	}
	fflush(store->file);
	return RC_OK;
}

StoreRC setTID(void* tidStore, unsigned index, char* tid){
	TIDStore* store = (TIDStore*)tidStore;
	unsigned tabIndex;

	if (index >= store->end || store->table[index].tid[0] != 0) return InvalidParameter;

	for (tabIndex=0; tabIndex<store->end; tabIndex++){
		if (tidEquals(tid, store->table[tabIndex].tid)){
			return AlreadyExisting;
		}
	}

	if (fseek(store->file, store->table[index].index, SEEK_SET)){
		perror("Error setting TID: ");
		return IOError;
	}
	
	if(fwrite(tid, sizeof(char), 24, store->file) != 24){
		perror("IO Error: ");
		return IOError;
	}
	fflush(store->file);

	memcpy(store->table[index].tid, tid, sizeof(char)*24);
	store->initials--;
	return RC_OK;
}

StoreRC getDetails(void* tidStore, unsigned index, char* tid, char* docnum){
	TIDStore* store = (TIDStore*)tidStore;

	if (index >= store->end || store->table[index].tid[0] == 1) return InvalidParameter;

	memcpy(tid, store->table[index].tid, 24);
	if (fseek(store->file, store->table[index].index + 24, SEEK_SET)){
		perror("Error getting error message: ");
		return IOError;
	}

	if (fread(docnum, sizeof(char), 16, store->file) != 16){
		perror("Error getting error message: ");
		return IOError;
	}

	return RC_OK;
}

StoreRC getErrorMessage(void* tidStore, unsigned index, char* errorMessage){
	TIDStore* store = (TIDStore*)tidStore;

	if (index >= store->end || errorMessage == NULL) return InvalidParameter;

	if (fseek(store->file, store->table[index].index + 41, SEEK_SET)){
		perror("Error getting error message: ");
		return IOError;
	}
	if (errorMessage != NULL){
		fread(errorMessage, sizeof(char), 80, store->file);
		errorMessage[80] = 0;
	}
	return RC_OK;
}

StoreRC deleteEntry(void* tidStore, unsigned index){
	TIDStore* store = (TIDStore*)tidStore;
	Link* entry;
	int i;

	if (index >= store->end) return InvalidParameter;

	if (fseek(store->file, store->table[index].index, SEEK_SET)){
		perror("Error deleting TID: ");
		return IOError;
	}

	i = fputc(1, store->file);
	if (i != 1){
		perror("IO Error: ");
		return IOError;
	}
	fflush(store->file);

	if (store->table[index].tid[0] == 0) store->initials--;
	store->table[index].tid[0] = (char)1;

	entry = (Link*)malloc(sizeof(Link));
	if (entry != NULL){
		entry->index = index;
		entry->fileIndex = store->table[index].index;
		entry->next = store->freeEntry;
		store->freeEntry = entry;
	}

	return RC_OK;
}

StoreRC getInitialEntries(void* tidStore, unsigned* numEntries, unsigned** indices){
	TIDStore* store = (TIDStore*)tidStore;
	unsigned i, j;
	unsigned* arr = (unsigned*)malloc(sizeof(unsigned)* store->initials);
	if (arr == NULL) return OutOfMemory;

	*indices = arr;
	*numEntries = store->initials;

	for (i=0, j=0; i<store->end && j<store->initials; i++){
		if (store->table[i].tid[0] == 0){
			*arr = i;
			arr++;j++;
		}
	}
	return RC_OK;
}

StoreRC printEntry(void* tidStore, unsigned index){
	TIDStore* store = (TIDStore*)tidStore;
	char buf[81] = "";
	int i;

	if (index >= store->end) return InvalidParameter;

	if (fseek(store->file, store->table[index].index + 24, SEEK_SET)){
		perror("Error reading file: ");
		return IOError;
	}

	memcpy(buf, store->table[index].tid, sizeof(char)*24);
	printf("TID:\t%s\n", buf);

	if(fread(buf, sizeof(char), 16, store->file) != 16){
		perror("Error reading file: ");
		return IOError;
	}
	buf[16] = 0;
	printf("DOCNUM:\t%s\n", buf);

	i = fgetc(store->file);
	if (i == EOF){
		perror("Error reading file: ");
		return IOError;
	}
	switch(i){
		case Status_Created: printf("Status:\tCreated\n");break;
		case Status_Executed: printf("Status:\tExecuted\n");break;
		case Status_Committed: printf("Status:\tCommitted\n");break;
		case Status_RolledBack: printf("Status:\tRolledBack\n");break;
		case Status_Confirmed: printf("Status:\tConfirmed\n");
	}

	if (i == Status_RolledBack){
		if(fread(buf, sizeof(char), 80, store->file) != 80){
			perror("Error reading file: ");
			return IOError;
		}
		buf[80] = 0;
		printf("Error:\t%s\n", buf);
	}
	return RC_OK;
}

StoreRC overView(void* tidStore){
	TIDStore* store = (TIDStore*)tidStore;
	unsigned i;
	TIDStatus status;
	char tid[25];
	char docnum[17];
	char statusText[11];
	char error[81];

	tid[24] = docnum[16] = statusText[10] = error[80] = 0;

	printf("\nIndex\tTID                      DOCNUM           Status     Error message\n\n");
	for (i=0; i<store->end; i++){
		if (store->table[i].tid[0] != 1){
			if (fseek(store->file, store->table[i].index + 24, SEEK_SET)) goto ioerror;
			if (fread(docnum, sizeof(char), 16, store->file) != 16) goto ioerror;
			status = fgetc(store->file);
			if (status == EOF) goto ioerror;
			if (status == Status_RolledBack){
				if (fread(error, sizeof(char), 80, store->file) != 80) goto ioerror;
			}
			else *error = 0;
			switch(status){
				case Status_Created: sprintf(statusText,    "Created");break;
				case Status_Executed: sprintf(statusText,   "Executed");break;
				case Status_Committed: sprintf(statusText,  "Committed");break;
				case Status_RolledBack: sprintf(statusText, "RolledBack");break;
				case Status_Confirmed: sprintf(statusText,  "Confirmed");
			}
			memcpy(tid, store->table[i].tid, sizeof(char)*24);
			printf("%d\t%24s %s %s %s\n", i, tid, docnum, statusText, error);
		}
	}
	return RC_OK;
	ioerror: return IOError;
}

StoreRC saveMessageBody(RFC_FUNCTION_HANDLE iDoc){
	RFC_TABLE_HANDLE table;
	RFC_RC rc;
	unsigned lines = 0, i;
	SAP_UC filename[22], buf[73];
	RFC_ERROR_INFO errorInfo;
	FILE* file;

	rc = RfcGetTable(iDoc, cU("IDOC_DATA_REC_40"), &table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting IDOC_DATA_REC_40: %s\n"), errorInfo.message);
		return NotFound;
	}
	RfcGetRowCount(table, &lines, NULL);
	if (lines == 0) return RC_OK;

	RfcMoveToFirstRow(table, NULL);
	rc = RfcGetNum(table, cU("DOCNUM"), filename, 16, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting DOCNUM: %s\n"), errorInfo.message);
		return NotFound;
	}
	strcpyU(filename+16, cU(".idoc"));

	file = fopenU(filename, cU("w"));
	if (file == NULL){
		perror("Error opening file: ");
		return IOError;
	}

	for (i=0; i<lines; i++){
		RfcMoveTo(table, i, NULL);
		RfcGetString(table, cU("SDATA"), buf, 73, NULL, NULL);
		fprintfU(file, cU("%s\n"), buf);
	}
	fclose(file);
	return RC_OK;
}

StoreRC readMessageBody(RFC_FUNCTION_HANDLE iDoc){
	RFC_TABLE_HANDLE table;
	RFC_RC rc;
	SAP_UC filename[22], buf[73];
	RFC_ERROR_INFO errorInfo;
	FILE* file;
	unsigned i = 0;

	rc = RfcGetTable(iDoc, cU("IDOC_CONTROL_REC_40"), &table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting IDOC_CONTROL_REC_40: %s\n"), errorInfo.message);
		return NotFound;
	}

	rc = RfcMoveToFirstRow(table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting DOCNUM: %s\n"), errorInfo.message);
		return NotFound;
	}
	rc = RfcGetNum(table, cU("DOCNUM"), filename, 16, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting DOCNUM: %s\n"), errorInfo.message);
		return NotFound;
	}

	strcpyU(filename+16, cU(".idoc"));

	rc = RfcGetTable(iDoc, cU("IDOC_DATA_REC_40"), &table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting IDOC_DATA_REC_40: %s\n"), errorInfo.message);
		return NotFound;
	}

	file = fopenU(filename, cU("r"));
	if (file == NULL){
		perror("Error opening file: ");
		return IOError;
	}

	RfcDeleteAllRows(table, NULL); // Too lazy to reuse the rows here as well...
	while (fscanfU(file, cU("%73s"), buf) > 0){
		RfcAppendNewRow(table, &errorInfo);
		if (errorInfo.code != RFC_OK){
			printfU(cU("Error appending IDOC_DATA_REC_40: %s\n"), errorInfo.message);
			fclose(file);
			return OutOfMemory;
		}
		RfcSetString(table, cU("SDATA"), buf, strlenU(buf), NULL);
		RfcSetString(table, cU("SEGNAM"), cU("E1TXTRW"), 7, NULL);
		RfcSetString(table, cU("MANDT"), cU("000"), 3, NULL);
		RfcSetChars(table, cU("DOCNUM"), filename, 16, NULL);
		convertToNUMC(++i, buf);
		RfcSetChars(table, cU("SEGNUM"), buf+10, 6, NULL);
	}
	fclose(file);
	return RC_OK;
}
StoreRC deleteMessageBody(RFC_FUNCTION_HANDLE iDoc){
	RFC_TABLE_HANDLE table;
	RFC_RC rc;
	SAP_UC filename[22];
	RFC_ERROR_INFO errorInfo;

	rc = RfcGetTable(iDoc, cU("IDOC_CONTROL_REC_40"), &table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting IDOC_CONTROL_REC_40: %s\n"), errorInfo.message);
		return NotFound;
	}

	rc = RfcMoveToFirstRow(table, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting DOCNUM: %s\n"), errorInfo.message);
		return NotFound;
	}
	rc = RfcGetNum(table, cU("DOCNUM"), filename, 16, &errorInfo);
	if (rc != RFC_OK){
		printfU(cU("Error getting DOCNUM: %s\n"), errorInfo.message);
		return NotFound;
	}

	strcpyU(filename+16, cU(".idoc"));

	if (removeU(filename)){
		perror("Error deleting file: ");
		return IOError;
	}
	return RC_OK;
}